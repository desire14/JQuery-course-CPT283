function area(height,weight) {
    var area = height * weight
    return area;
}
var alphabet = new Array();
for (var i = 0; i !=26; ++i)
{
    
    alphabet.push 
    (
        String.fromCharCode(i + 65)
    );
}

$(document).ready(function() {
    $("#letters") .addClass("Christmas");

});

$(document).ready(function() {
    $("#calculation") .addClass("Easter");

});