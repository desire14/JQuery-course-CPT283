$(document).ready(function() {
    $("#name").addClass("formal");
    $("#books").addClass("list");

}); 